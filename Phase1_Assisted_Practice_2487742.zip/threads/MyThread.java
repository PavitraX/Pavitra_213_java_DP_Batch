package threads;

public class MyThread {
}
