package diamond;
interface First {
	 default void show() 
	    { 
	        System.out.println("Default First"); 
	    } 
}

